# requirements: matplotlib, pandas, pyyaml
import re, json, zipfile, yaml
from collections import defaultdict, Counter
import matplotlib.pyplot as plt
import pandas as pd
from pathlib import Path

ZIP_SCHEMA = Path("/mnt/data/ALL_SCH.SCR_,CAL.zip")
ZIP_MARKERS = Path("/mnt/data/FIXED_Marker_4.0.zip")

def read_from_zip(zpath, name):
    with zipfile.ZipFile(zpath, "r") as z:
        return z.read(name).decode("utf-8", errors="ignore")

schema_bundle = json.loads(read_from_zip(ZIP_SCHEMA, "schema_full_bundle.json"))
sets_cfg = json.loads(read_from_zip(ZIP_SCHEMA, "sets_config.json"))
weights = json.loads(read_from_zip(ZIP_SCHEMA, "weights.json"))

def load_regex_markers_from_bundle(sb):
    reg = {}
    for group in ["ATO","SEM","CLU","MEMA"]:
        for e in sb.get(group, []):
            pat = e.get("pattern")
            if not pat: 
                continue
            try:
                reg[e["id"]] = re.compile(pat)
            except re.error:
                pass
    return reg

REGEX_MARKERS = load_regex_markers_from_bundle(schema_bundle)
E_SET = set(sets_cfg["E"]); D_SET = set(sets_cfg["D"])
PRIMARY = schema_bundle["metrics"]["primaryOrder"]

# heuristische Map aus Beschreibungen → primaryOrder (nur wenn explizit)
def build_primary_map(sb, primary):
    out = {}
    for group in ["ATO","SEM","CLU","MEMA"]:
        for e in sb.get(group, []):
            desc = e.get("description","")
            for cat in primary:
                if re.search(cat, desc, re.IGNORECASE):
                    out[e["id"]] = cat
                    break
    return out

MARKER_TO_PRIMARY = build_primary_map(schema_bundle, PRIMARY)

def chunk_lines(text):
    messages = []
    for i, line in enumerate(l for l in (x.strip() for x in text.splitlines()) if l):
        m = re.match(r"^([^:]{1,40}):\s*(.+)$", line)
        spk, msg = (m.group(1), m.group(2)) if m else ("Unknown", line)
        messages.append({"i": i, "speaker": spk, "text": msg})
    return messages

def analyze(text):
    msgs = chunk_lines(text)
    hits = []
    for m in msgs:
        for mid, creg in REGEX_MARKERS.items():
            if creg.search(m["text"]):
                hits.append({"i": m["i"], "speaker": m["speaker"], "marker": mid})
    prim = Counter()
    per_speaker = defaultdict(Counter)
    E, D = 0, 0
    wsum = 0.0
    for h in hits:
        mid = h["marker"]; spk = h["speaker"]
        per_speaker[spk][mid] += 1
        if mid in E_SET: E += 1
        if mid in D_SET: D += 1
        if mid in MARKER_TO_PRIMARY: prim[MARKER_TO_PRIMARY[mid]] += 1
        wsum += float(weights["marker_weights"].get(mid, 1.0))
    return {
        "messages": msgs, "hits": hits,
        "primary_counts": dict(prim),
        "speaker_counts": {k: dict(v) for k,v in per_speaker.items()},
        "E": E, "D": D, "weighted_sum": wsum, "total_markers": len(hits)
    }

def donut(counts, title, outfile):
    if not counts: return None
    labels, sizes = list(counts.keys()), list(counts.values())
    fig, ax = plt.subplots()
    wedges, texts = ax.pie(sizes, labels=labels, wedgeprops=dict(width=0.4))
    ax.set_title(title)
    plt.tight_layout()
    fig.savefig(outfile, dpi=144)
    plt.close(fig)
    return outfile

def comparison_table(res):
    rows = []
    for spk, cnt in res["speaker_counts"].items():
        total = sum(cnt.values())
        e = sum(v for k,v in cnt.items() if k in E_SET)
        d = sum(v for k,v in cnt.items() if k in D_SET)
        rows.append({
            "speaker": spk, "markers_total": total, "E": e, "D": d,
            "E_share": (e / total) if total else 0.0
        })
    return pd.DataFrame(rows).sort_values("markers_total", ascending=False)

# --- Beispielnutzung ---
if __name__ == "__main__":
    text = """A: Ich misstraue dir komplett.
B: Das stimmt nicht! Ich habe das nie getan.
A: Du versuchst mich zu kontrollieren.
B: Sorry, tut mir leid.
A: Lass uns transparent sein, bitte.
B: Können wir jetzt nicht darüber reden? Später."""
    res = analyze(text)
    print(res["primary_counts"])
    print(comparison_table(res))
    donut(res["primary_counts"], "Primärkategorien", "donut_primary.png")

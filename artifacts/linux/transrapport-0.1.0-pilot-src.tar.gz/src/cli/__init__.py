"""
TransRapport CLI Module
Constitutional compliance: Uses existing LD-3.4 framework, no modifications
"""

from .main import main_cli

__all__ = ['main_cli']
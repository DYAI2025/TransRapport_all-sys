"""TransRapport Documentation Validator Library.

A library for validating documentation consistency and managing cross-references
in the TransRapport marker engine documentation.
"""

__version__ = "1.0.0"
__author__ = "TransRapport Team"
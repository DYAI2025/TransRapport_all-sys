Some content without a title

This has [broken markdown link]( with missing closing paren

And [missing-file.md](missing-file.md) links to nothing.

UNDEFINED_MARKER_TYPE references.

**CLU** used without proper definition context.

Short content under 100 characters triggers warnings.

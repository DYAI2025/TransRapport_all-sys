No main title - this should be flagged

Missing key terms - only some ATO definitions

## ATO (Atomic Marker)
**ATO** · Basic atomic markers

## SEM (Semantic Marker)  
**SEM** · Groups atomic markers

Missing CLU and MEMA definitions!
This should trigger validation errors.
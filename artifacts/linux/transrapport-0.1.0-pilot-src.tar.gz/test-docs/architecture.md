# System Architecture

## Overview

TransRapport uses a modular architecture with clear separation of concerns.

## Components

- Engine: Core processing logic
- CLI: Command-line interface
- Storage: SQLite database

## Data Flow

Input → Processing → Storage → Output

## Missing Reference

This link is broken: [nonexistent.md](nonexistent.md)
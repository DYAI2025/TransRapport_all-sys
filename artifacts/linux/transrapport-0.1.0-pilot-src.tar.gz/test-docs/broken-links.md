# Test Document with Broken Links

This document has [broken link](missing-file.md) and [another broken link](also-missing.md#section).

It also has [malformed link]( syntax error here.

Some text with UNKNOWN_MARKER reference.

See also: [working link](terminologie.md) which should be valid.

Missing terminology: UNDEFINED_TERM should be flagged.